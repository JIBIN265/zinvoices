sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("zinvoicesmain.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);